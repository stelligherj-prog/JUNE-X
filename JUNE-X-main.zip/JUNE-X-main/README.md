
<div align="center"> 
<strong>JUNE X </strong>
    <br>
  <a href="https://git.io/typing-svg"> 
    <img src="https://readme-typing-svg.demolab.com?font=Rockwell&size=50&pause=1000&color=33ff00&center=true&width=910&height=100&lines=June-Official;Multi+Device+Whatsapp+Bot;Made+by+supreme" alt="Typing SVG" />
  </a> 
</div> 

<div align="center"> 
  <a href=""> 
    <img src="https://files.catbox.moe/pr5ynj.jpg" alt="JUNE X" height="300"> 
  </a> 
</div>

---
<div align="center">
<strong>1. FORK JUNE REPO</strong>
    <br>
  <a href="https://github.com/vinpink2/JUNE-X/fork">
    <img src="https://img.shields.io/badge/Fork%20June%20X-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkblue&color=darkblue" alt="FORK REPO"/>
  </a>
</div>
<br>
<p align="center">  
<strong>2. DOWNLOAD BOT ZIP</strong>
    <br>
    <a href="https://codeload.github.com/vinpink2/JUNE-X/zip/refs/heads/main" target="_blank">
        <img alt="Download zip" src="https://img.shields.io/badge/JUNE%20 X ZIP-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkorange&color=purple"/>
    </a>
</p>

<div align="center">
<strong>3. SESSION PAIR</strong>
    <br>
  <a href="https://pair-me1-aa017257f6a4.herokuapp.com/" target="_blank">
    <img src="https://img.shields.io/badge/pair %20code 1-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkblue&color=darkred" alt="PAIR"/>
  </a>
</div>

<p align="center">
    <a href="https://pair-me2-f25b48995f39.herokuapp.com/" target="_blank">
        <img alt="Download zip" src="https://img.shields.io/badge/PAIR CODE%20 2-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkorange&color=darkblue"/>
    </a>
</p>

<p align="center">
<strong>4. DEPLOY TO HEROKU</strong>
    <br>
    <a href="https://dashboard.heroku.com/new?template=https://github.com/vinpink2/JUNE-X" target="_blank">
        <img alt="Deploy to heroku" src="https://img.shields.io/badge/Deploy Now-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=purple&color=purple"/>
    </a>
</p>

<p align= "center">
<strong>5. DEPLOY NOW ON ALL PANELS</strong>
</p> 

[![Typing SVG](https://readme-typing-svg.demolab.com/?lines=The+bot+supports+deployment;on+all+Free+Panels+easily)](https://git.io/typing-svg)



    



